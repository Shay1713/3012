
% Lab 1 
% Shay Mitton
% ECE 3012
% D'23

%% Starting the Code
clear all
close all
syms s
% table parameters & measurements
g = 9.8;
L = 11.2;
mp = 381;
Ip = 0.00616;
mw = 36;
icmw = 0.00000746;
rw = 2.1;
R = 4.4;
kb = 0.444;
kt = 0.470;
% state space equations
q1 = icmw + rw * (mp * (L + rw) + mw*rw);
q2 = icmw * (Ip + (L^2)*mp) + (rw^2) * (Ip * (mp + mw)) + (L^2) * mp * mw;
q3 = Ip + L * mp * (L + rw);
disp('q1 = '); disp(q1); % 1.0800e+04
disp('q2 = '); disp(q2); % 1.7205e+06
disp('q3 = '); disp(q3); % 5.6754e+04
disp(' '); disp(' ');

%% QUESTION 1
% Compute the state-space model for the given parameter values where the output is equal to α.
A = [0 1 0 0; (g*L*mp*((mp+mw)*(rw^2)+icmw))/q2 -1*(q1*kb*kt)/(q2*R) 0 -1*(q1*kb*kt)/(q2*R*rw); 0 0 0 1; (g*(L^2)*(mp^2)*(rw^2))/q2 -1*(q3*kb*kt*rw)/(q2*R) 0 -1*(q3*kb*kt)/(q2*R)];
B = [0; -1*(q1*kt)/(q2*R); 0; -1*(q3*kt*rw)/(q2*R)];
C = [1 0 0 0];
D = 0;
% computing the values of the state model that are formulas
A1 = (g*L*mp*((mp+mw)*(rw^2)+icmw))/q2; 
disp('A1 is'); disp(A1); % 44.6969
A2 = -1*(q1*kb*kt)/(q2*R); 
disp('A2 is'); disp(A2); % -2.9771e-04
A4 = -1*(q1*kb*kt)/(q2*R*rw); 
disp('A4 is'); disp(A4); % -1.4177e-04
A11 = (g*(L^2)*(mp^2)*(rw^2))/q2; 
disp('A11 is'); disp(A11); % 457.3874
A22 = -1*(q3*kb*kt*rw)/(q2*R); 
disp('A22 is'); disp(A22); % -0.0033
A44 = -1*(q3*kb*kt)/(q2*R); 
disp('A44 is'); disp(A44); % -0.0016
B2 = -1*(q1*kt)/(q2*R); 
disp('B2 is'); disp(B2); % -6.7051e-04
B4 = -1*(q3*kt*rw)/(q2*R); 
disp('B4 is'); disp(B4); % -0.0074


%% QUESTION 2
% Compute the transfer function from input V(t) to output α(t).
format long
[num,den] = ss2tf(A, B, C, D); % getting the numerator and denominators
disp('total num is');
disp(num);
disp('total den is');
disp(den); 
disp('Q2: Transfer Function');
transfer_function = tf(num,den); % getting transfer function equation
figure; % plotting transfer function
bode(transfer_function); % citation: https://www.mathworks.com/help/control/ug/plotting-system-responses.html
title('Q2: Transfer Function Bode Plots');

transfer_function2 = C *inv(s * eye(4) - A)* B + D;
disp('Q2: Transfer Function');
disp(transfer_function2); 
% (12368749889199202*(2305843009213693952*s + 3607331900216889))/(- 42535295865117307932921825928971026432*s^3 
% - 79206583938566159591905553771659264*s^2 + 1901195190866511078379084520764361250635*s 
% + 216230285280176978917243307261689856) - 44618186041112393819948449944256/
% (- 42535295865117307932921825928971026432*s^3 - 79206583938566159591905553771659264*s^2 
% + 1901195190866511078379084520764361250635*s + 216230285280176978917243307261689856)

disp('num1'); % s^4 0   % getting TF num values
format long
disp(num(1));
disp('num2'); % s^3 0
format long
disp(num(2));
disp('num3'); % s^2 -6.705112750399810e-04
format long
disp(num(3));
disp('num4'); % s^1 2.554888831734579e-19
format long
disp(num(4));
disp('num5'); % s^0 -4.532455538564416e-19
format long
disp(num(5));
disp('den1'); % s^4 1   % getting TF den values
format long
disp(den(1));
disp('den2'); % s^3 0.001862137839356
format long
disp(den(2));
disp('den3'); %s^2 -44.696884133481682
format long
disp(den(3));
disp('den4'); % s^1 -0.005083549576471
format long
disp(den(4));
disp('den5'); % s^0 0
format long
disp(den(5));








%% QUESTION 3
% Compute and plot the open-loop impulse response of the system.
figure;
impulse(transfer_function); % plotting impulse response
title('Q3: Open-Loop Impulse Responce');
disp('impulse function is '); 
% https://www.mathworks.com/help/symbolic/sym.ilaplace.html 
disp(ilaplace(transfer_function2)); 
% 28520395464722631585201357590626304*symsum(-(exp(root(z^3 + (34350380152539557*z^2)/18446744073709551616 - 
% (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 - 
% 412426539001802404245840658687/81129638414606681695789005144064, z, k)*t)*root(z^3 + 
% (34350380152539557*z^2)/18446744073709551616 - (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 
% - 412426539001802404245840658687/81129638414606681695789005144064, z, k))/(158413167877132319183811107543318528*root(z^3 + 
% (34350380152539557*z^2)/18446744073709551616 - (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 - 
% 412426539001802404245840658687/81129638414606681695789005144064, z, k) + 127605887595351923798765477786913079296*root(z^3 + 
% (34350380152539557*z^2)/18446744073709551616 - (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 - 
% 412426539001802404245840658687/81129638414606681695789005144064, z, k)^2 - 1901195190866511078379084520764361250635), k, 1, 3) - 
% 1196086124221678*symsum(-exp(t*root(z^3 + (34350380152539557*z^2)/18446744073709551616 - 
% (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 
% - 412426539001802404245840658687/81129638414606681695789005144064, z, k))/(127605887595351923798765477786913079296*root(z^3 + 
% (34350380152539557*z^2)/18446744073709551616 - (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 - 
% 412426539001802404245840658687/81129638414606681695789005144064, z, k)^2 + 158413167877132319183811107543318528*root(z^3 + 
% (34350380152539557*z^2)/18446744073709551616 - (1901195190866511078379084520764361250635*z)/42535295865117307932921825928971026432 
% - 412426539001802404245840658687/81129638414606681695789005144064, z, k) - 1901195190866511078379084520764361250635), k, 1, 3)
 




%% QUESTION 4
% Compute and plot the step and ramp responses of the system.
figure;
step(transfer_function); % plotting unit step
legend('step');title('Q4: Step Responce');xlabel('Time'); ylabel('Amplitude');
disp('step function is ');
disp(transfer_function2/s);
% ((12368749889199202*(2305843009213693952*s + 3607331900216889))/(- 42535295865117307932921825928971026432*s^3 
% - 79206583938566159591905553771659264*s^2 + 1901195190866511078379084520764361250635*s + 
% 216230285280176978917243307261689856) - 44618186041112393819948449944256/(- 42535295865117307932921825928971026432*s^3 
% - 79206583938566159591905553771659264*s^2 + 1901195190866511078379084520764361250635*s + 
% 216230285280176978917243307261689856))/s
 
% ramp code from lecture 9 for computation of ramp response
t = linspace(0,1,1000);
ramp = t;
y_ramp = lsim(transfer_function,ramp,t);  % response of ramp input in time domain
figure; plot(t,y_ramp,'-');
%hold on; plot(t,ramp,'--'); hold off;
xlabel('Time (s)');
ylabel('Output y(t)');
legend('ramp');
title('Q4: Ramp Response');
disp('ramp function is ');
disp(transfer_function2/(s^2));
% ((12368749889199202*(2305843009213693952*s + 3607331900216889))/(- 42535295865117307932921825928971026432*s^3 
% - 79206583938566159591905553771659264*s^2 + 1901195190866511078379084520764361250635*s + 
% 216230285280176978917243307261689856) - 44618186041112393819948449944256/(- 42535295865117307932921825928971026432*s^3 
% - 79206583938566159591905553771659264*s^2 + 1901195190866511078379084520764361250635*s + 
% 216230285280176978917243307261689856))/s^2






%% QUESTION 5
% Compute and plot the system poles and zeros.
figure;
pzmap(transfer_function); % plot poles\zeros
title('Q5: Pole-Zero Map');
[z,p,k] = tf2zp(num,den); % citation: https://www.mathworks.com/help/signal/ref/tf2zp.html
disp('poles');
disp(p); % poles are ...
% 0
% -6.6864
% 6.6847
% -0.0001
disp('zeros');
disp(z); % zeros are ...
%   1.0e-07 *
% (0.0000 + 0.2600i)
% (0.0000 - 0.2600i)



%% QUESTION 6
% Determine whether the open-loop system is BIBO stable.

% did in lab report

%% QUESTION 7
% Compute the transfer function of the system from input V to output α with 
% a unity feedback controller with K = 1. Create a plot that shows how the 
% poles and zeros vary depending on the value of K.

K = 1; % also tried K = 5, 50, and 1/4

z = roots([0 -6.6864 6.6847 -0.0001 K]);
figure;
plot(real(z), imag(z), 'kx');
title('Poles when K=1');

K = [0 1];
z = [];
for i=1:length(K)
    z = [z ; roots([0 -6.6864 6.6847 -0.0001 K(i)])];
end

figure; plot(real(z), imag(z), 'kx');
title('Poles for K=0, K=1');

figure;
sys = tf(num,den);
rlocus(sys);


%% QUESTION 8
% Is there a value of K that stabilizes the system from input V to output 
% α under unity feedback? Verify your answer using a Routh-Hurwitz table.

% trying with K = 1
disp('Question 8');

K = 1/4;

% Col 2 Row 1
J1 = -44.6969 - K * [1e-3 * (-6.705)]; 
disp('J1 is'); disp(J1); % when K = 1/4 ... -44.695223749999997

% Col 3 Row 1
J2 = -K * (4.532455538564416e-19);
disp('J2 is '); disp(J2); % when K = 1/4 ... -1.133113884641104e-19

% Col 2 Row 2
J3 = -0.0051 + K * (2.554888831734579e-19);
disp('J3 is'); disp(J3); % when K = 1/4 ... -0.005100000000000

% Col 1 Row 3
G1 = ( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839);
disp('G1');disp(G1); % when K = 1/4 ... -41.958280048685189

% Col 2 Row 3
G2 = ( (-0.0051 + K * (2.554888831734579e-19))*(-K * (4.532455538564416e-19)) - 0 ) / (-0.0051 + K * (2.554888831734579e-19));
disp('G2');disp(G2); % when K = 1/4 ... -1.133113884641104e-19

% Col 1 Row 4
G3 = ( (( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839))*(-0.0051 + K * (2.554888831734579e-19)) - (0.001862137839)*(( (-0.0051 + K * (2.554888831734579e-19))*(-K * (4.532455538564416e-19)) - 0 ) / (-0.0051 + K * (2.554888831734579e-19))) ) / (( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839));
disp('G3');disp(G3); % when K = 1/4 ... -0.005100000000000

% Col 1 Row 5
G4 = ( (( (( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839))*(-0.0051 + K * (2.554888831734579e-19)) - (0.001862137839)*(( (-0.0051 + K * (2.554888831734579e-19))*(-K * (4.532455538564416e-19)) - 0 ) / (-0.0051 + K * (2.554888831734579e-19))) ) / (( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839)) )*(( (-0.0051 + K * (2.554888831734579e-19))*(-K * (4.532455538564416e-19)) - 0 ) / (-0.0051 + K * (2.554888831734579e-19))) - 0 ) / (( (( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839))*(-0.0051 + K * (2.554888831734579e-19)) - (0.001862137839)*(( (-0.0051 + K * (2.554888831734579e-19))*(-K * (4.532455538564416e-19)) - 0 ) / (-0.0051 + K * (2.554888831734579e-19))) ) / (( (0.001862137839356)*(-44.6969 - K *(6.705112750399810e-04)) - (1)*(-0.0051 + K * (2.554888831734579e-19)) ) / (0.001862137839)) );
disp('G4');disp(G4); % when K = 1/4 ... -1.133113884641104e-19


